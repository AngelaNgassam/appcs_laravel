<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('modeles_cartes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('etablissement_id')->nullable();
            $table->string('nom_modele', 100);
            $table->string('fichier_template', 191)->nullable();
            $table->string('apercu', 191)->nullable();
            $table->json('configuration')->nullable();
            $table->boolean('actif')->default(true);
            $table->boolean('est_defaut')->default(false);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('etablissement_id')
                  ->references('id')
                  ->on('etablissements')
                  ->onDelete('cascade');

            $table->index('etablissement_id');
            $table->index('actif');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('modeles_cartes');
    }
};
